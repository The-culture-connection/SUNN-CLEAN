'use client';
import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { clientAuth, signInWithEmailAndPassword, FirebaseConfigError } from '@/lib/firebaseClient';

export function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setErr('');
    try {
      const cred = await signInWithEmailAndPassword(clientAuth(), email.trim(), password);
      const idToken = await cred.user.getIdToken();
      const res = await fetch('/api/auth/session', {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ idToken }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) { setErr(data.error ?? 'Sign-in failed.'); return; }
      router.push(params.get('next') || '/');
      router.refresh();
    } catch (e: unknown) {
      // A missing build-time config is a setup problem, not a wrong password.
      if (e instanceof FirebaseConfigError) { setErr(e.message); return; }
      const code = (e as { code?: string })?.code ?? '';
      setErr(
        code.includes('invalid-credential') || code.includes('wrong-password') || code.includes('user-not-found')
          ? 'That email or password is not right.'
          : code.includes('too-many-requests')
            ? 'Too many attempts. Wait a minute and try again.'
            : code.includes('invalid-api-key') || code.includes('api-key-not-valid')
              ? 'The Firebase Web API key on this service is not valid. Check NEXT_PUBLIC_FIREBASE_API_KEY and redeploy.'
            : code.includes('operation-not-allowed')
              ? 'Email/password sign-in is switched off for this Firebase project. Turn it on under Authentication → Sign-in method.'
            // A dropped connection must not read as a wrong password, or you
            // spend ten minutes doubting a password that was fine all along.
            : code.includes('network-request-failed')
              ? "Couldn't reach the sign-in service. Check your internet connection and try again — your password is probably fine."
            : 'Sign-in failed. Please try again.',
      );
    } finally { setBusy(false); }
  }

  return (
    <form onSubmit={submit}>
      <div className="field">
        <label htmlFor="e">Email</label>
        <input id="e" type="email" autoComplete="username" required value={email}
          onChange={(ev) => setEmail(ev.target.value)} />
      </div>
      <div className="field">
        <label htmlFor="p">Password</label>
        <input id="p" type="password" autoComplete="current-password" required value={password}
          onChange={(ev) => setPassword(ev.target.value)} />
      </div>
      {err && <div className="err" role="alert">{err}</div>}
      <button className="btn btn-primary" style={{ width: '100%' }} disabled={busy}>
        {busy ? 'Signing in…' : 'Sign in'}
      </button>
    </form>
  );
}
