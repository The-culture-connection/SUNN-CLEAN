'use client';

import { initializeApp, getApps, type FirebaseApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, type Auth } from 'firebase/auth';

/**
 * The ONLY place the browser touches Firebase: exchanging an email and password
 * for an ID token, which is immediately swapped server-side for an httpOnly
 * session cookie. The browser never reads or writes Firestore.
 *
 * On the Web API key: it is NOT a secret. It ships inside this page's
 * JavaScript, so anyone can read it. It identifies the project; it grants
 * nothing. Access is controlled by the password, the `admin: true` custom claim
 * and ADMIN_ALLOWED_EMAILS. Restrict it by HTTP referrer in Google Cloud
 * Console to stop other sites burning your quota.
 *
 * Only the ADMIN app needs this. The customer site has no Firebase browser SDK
 * at all, because customers never sign in.
 */

export class FirebaseConfigError extends Error {}

function readConfig() {
  const apiKey = process.env.NEXT_PUBLIC_FIREBASE_API_KEY;
  const authDomain = process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN;
  const projectId = process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID;

  // NEXT_PUBLIC_* values are baked in at BUILD time, not read at runtime. If
  // they were missing when this service was built, adding them to Railway now
  // is not enough — the service has to be redeployed. Say so plainly rather
  // than letting the SDK throw "auth/invalid-api-key".
  const missing = [
    !apiKey && 'NEXT_PUBLIC_FIREBASE_API_KEY',
    !authDomain && 'NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN',
    !projectId && 'NEXT_PUBLIC_FIREBASE_PROJECT_ID',
  ].filter(Boolean) as string[];

  if (missing.length) {
    throw new FirebaseConfigError(
      `Sign-in isn't configured yet — ${missing.join(', ')} ${
        missing.length === 1 ? 'is' : 'are'
      } missing. Add ${missing.length === 1 ? 'it' : 'them'} to this service's ` +
      'environment variables in Railway, then redeploy (these values are built ' +
      'into the page, so a restart alone will not pick them up).',
    );
  }

  return { apiKey, authDomain, projectId };
}

let app: FirebaseApp | undefined;

function clientApp(): FirebaseApp {
  if (app) return app;
  const existing = getApps();
  if (existing.length) { app = existing[0]; return app; }
  app = initializeApp(readConfig());
  return app;
}

export function clientAuth(): Auth { return getAuth(clientApp()); }
export { signInWithEmailAndPassword };
